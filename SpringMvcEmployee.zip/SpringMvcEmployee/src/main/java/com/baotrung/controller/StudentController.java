package com.baotrung.controller;

import java.net.Authenticator.RequestorType;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.baotrung.model.Student;
import com.baotrung.services.StudentServices;

@Controller
public class StudentController {
	@Autowired
	private StudentServices studentServices;
	
	@RequestMapping(value = "/addStudent", method = RequestMethod.GET)
    public ModelAndView newContact(ModelAndView model) {
        Student st = new Student();
        model.addObject("student", st);
        model.setViewName("addStudent");
        return model;
    }
	
	@RequestMapping(value="/saveStudent",method=RequestMethod.POST)
	public String addStudent(@ModelAttribute("student")Student student,BindingResult result) {
		if(result.hasErrors()) {
			System.out.println(result.hasErrors());
			return "addStudent";
		}
		if(student.getId()==0) {
			this.studentServices.createStudent(student);
		}else{
			this.studentServices.updateStudent(student);
		}
		
		return "redirect:/";
	}
	
	@RequestMapping("/")
	public String getAll(ModelMap model,HttpServletRequest request,@RequestParam(required=false)Integer page) {
		List<Student> student = studentServices.getAll();
		PagedListHolder<Student> pagedListHolder = new PagedListHolder<Student>(student);
		pagedListHolder.setPageSize(5);
		model.addAttribute("maxPages",pagedListHolder.getPageCount());
		if(page==null||page<0||page>pagedListHolder.getPageCount())page=1;
		model.addAttribute("page",page);
		if(page==null||page<0||page>pagedListHolder.getPageCount()) {
			pagedListHolder.setPage(0);
			model.addAttribute("students",pagedListHolder.getPageList());
			
		}else if(page<=pagedListHolder.getPageCount()) {
			pagedListHolder.setPage(page-1);
			model.addAttribute("students",pagedListHolder.getPageList());
		}
		return "account";
		
	}
	@RequestMapping(value="/deleteStudent/{id}",method=RequestMethod.GET)
	public String deleteStudent(@PathVariable("id")int id) {
		studentServices.deleteStudent(id);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/editStudent", method = RequestMethod.GET)
    public ModelAndView editContact(HttpServletRequest request) {
        int id = Integer.parseInt(request.getParameter("id"));
        Student st = studentServices.getStudentById(id);
        ModelAndView model = new ModelAndView("addStudent");
        model.addObject("student", st);
 
        return model;
    }
	@RequestMapping(value ="/searchByNameStudent",method = RequestMethod.GET)
	public String searchByNameStudent(String searchName,ModelMap model) {
		if(searchName == "") {
			return "redirect:/";
		}
		List<Student> st = studentServices.findStudentByName(searchName);
		model.addAttribute("students",st);
		return "account";
	}
	
		
}
